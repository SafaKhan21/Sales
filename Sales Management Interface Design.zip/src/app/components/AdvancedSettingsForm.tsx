import React from 'react';
import { useForm } from 'react-hook-form';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Settings, Database, FileOutput, Mail, Printer, AlertTriangle } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { Alert, AlertDescription } from './ui/alert';

interface AdvancedSettingsFormData {
  bankAccount: string;
  cashAccount: string;
  reportPath: string;
  excelPath: string;
  printerType: string;
  emailServer: string;
}

export const AdvancedSettingsForm: React.FC = () => {
  const { t } = useApp();
  const { register, watch, setValue } = useForm<AdvancedSettingsFormData>({
    defaultValues: {
      bankAccount: '1234567890',
      cashAccount: '0987654321',
      reportPath: '/reports/output',
      excelPath: '/exports/excel',
      printerType: 'thermal',
      emailServer: 'smtp.company.com',
    }
  });

  const printerType = watch('printerType');

  return (
    <div className="space-y-6">
      {/* Warning Alert */}
      <Alert className="border-accent bg-accent/10">
        <AlertTriangle className="h-4 w-4 text-accent" />
        <AlertDescription className="text-sm">
          <strong>{t('advanced.visibilityNote')}</strong> - These settings require elevated permissions 
          and may affect system-wide operations.
        </AlertDescription>
      </Alert>

      {/* Financial Accounts */}
      <Card className="border-2 border-primary/20 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-primary/5 to-primary/15">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
              <Database className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <CardTitle className="text-xl">{t('advanced.financialAccounts')}</CardTitle>
              <CardDescription>Configure default financial account numbers</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="bankAccount">{t('advanced.bankAccount')}</Label>
              <Input 
                id="bankAccount" 
                {...register('bankAccount')} 
                placeholder="Enter bank account number"
                className="font-mono"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cashAccount">{t('advanced.cashAccount')}</Label>
              <Input 
                id="cashAccount" 
                {...register('cashAccount')} 
                placeholder="Enter cash account number"
                className="font-mono"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Integration & Export Paths */}
      <Card className="border-2 border-secondary/20 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-secondary/5 to-secondary/15">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-secondary flex items-center justify-center">
              <FileOutput className="w-5 h-5 text-secondary-foreground" />
            </div>
            <div>
              <CardTitle className="text-xl">{t('advanced.integrationPaths')}</CardTitle>
              <CardDescription>Define file system paths for reports and exports</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6 space-y-4">
          <div className="grid grid-cols-1 gap-4">
            <div className="space-y-2">
              <Label htmlFor="reportPath">{t('advanced.reportPath')}</Label>
              <Input 
                id="reportPath" 
                {...register('reportPath')} 
                placeholder="/path/to/reports"
                className="font-mono text-sm"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="excelPath">{t('advanced.excelPath')}</Label>
              <Input 
                id="excelPath" 
                {...register('excelPath')} 
                placeholder="/path/to/excel"
                className="font-mono text-sm"
              />
            </div>
          </div>

          <div className="bg-secondary/10 border border-secondary/30 rounded-lg p-4 mt-4">
            <p className="text-sm text-muted-foreground">
              <strong className="text-foreground">Note:</strong> Ensure these paths exist and have 
              appropriate read/write permissions. Invalid paths may cause export failures.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Device & Printer Settings */}
      <Card className="border-2 border-accent/20 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-accent/5 to-accent/15">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-accent flex items-center justify-center">
              <Printer className="w-5 h-5 text-accent-foreground" />
            </div>
            <div>
              <CardTitle className="text-xl">{t('advanced.deviceSettings')}</CardTitle>
              <CardDescription>Configure hardware and peripherals</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="printerType">{t('advanced.printerType')}</Label>
            <Select value={printerType} onValueChange={(value) => setValue('printerType', value)}>
              <SelectTrigger className="h-11">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="laser">
                  <div className="flex items-center gap-2">
                    <Printer className="w-4 h-4" />
                    {t('printer.laser')}
                  </div>
                </SelectItem>
                <SelectItem value="inkjet">
                  <div className="flex items-center gap-2">
                    <Printer className="w-4 h-4" />
                    {t('printer.inkjet')}
                  </div>
                </SelectItem>
                <SelectItem value="thermal">
                  <div className="flex items-center gap-2">
                    <Printer className="w-4 h-4" />
                    {t('printer.thermal')}
                  </div>
                </SelectItem>
                <SelectItem value="dotMatrix">
                  <div className="flex items-center gap-2">
                    <Printer className="w-4 h-4" />
                    {t('printer.dotMatrix')}
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="bg-accent/10 border border-accent/30 rounded-lg p-4">
            <p className="text-sm text-muted-foreground">
              <strong className="text-foreground">Printer Type:</strong> {
                printerType === 'thermal' ? 'Thermal printers are ideal for receipts and labels with fast printing speeds.' :
                printerType === 'laser' ? 'Laser printers provide high-quality output for invoices and reports.' :
                printerType === 'inkjet' ? 'Inkjet printers offer color printing capabilities for marketing materials.' :
                'Dot matrix printers are reliable for multi-part forms and carbon copies.'
              }
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Email Settings */}
      <Card className="border-2 border-primary/20 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-primary/5 to-primary/15">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
              <Mail className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <CardTitle className="text-xl">{t('advanced.emailSettings')}</CardTitle>
              <CardDescription>Configure email server for notifications</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="emailServer">{t('advanced.emailServer')}</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                id="emailServer" 
                {...register('emailServer')} 
                placeholder="smtp.server.com"
                className="pl-10 font-mono text-sm"
              />
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {t('advanced.emailHelper')}
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
